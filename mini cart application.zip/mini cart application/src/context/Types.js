export const SHOW_HIDE_CART = "SHOW_HIDE_CART";
export const ADD_TO_CART = "ADD_TO_CART";
export const REMOVE_ITEM = "REMOVE_ITEM";
